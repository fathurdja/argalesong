<?php


$app["hostdb"]="localhost";
$app["db"]="Galesong_HR";
$app["userdb"]="afagl";
$app["passdb"]="#afagl#";
$app["portdb"]="3306";
$app["typehostdb"]="mysql";

 

 