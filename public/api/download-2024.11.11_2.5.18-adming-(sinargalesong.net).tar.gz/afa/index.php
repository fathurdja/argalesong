<?php 
	
	include "mylibs.php";
	$q = isset($_REQUEST["q"]) ? $_REQUEST["q"] : "";
	$idcmp = isset($_REQUEST["idcmp"]) ? $_REQUEST["idcmp"] : "";
	$idpt = isset($_REQUEST["idpt"]) ? $_REQUEST["idpt"] : "";
	$idafa = isset($_REQUEST["idafa"]) ? $_REQUEST["idafa"] : "0";
	
	
	switch ( $q ) 
	{
		case "afa":
		$textidafa = isset($_REQUEST["textidafa"]) ? $_REQUEST["textidafa"] : "ALL";
		if ( $textidafa == "ALL" )  
		{
			$sql = "select * from tvafa_realisasi where left(number,locate('/',number,1)-1)='$idcmp' and number<>''";
		}else
		{
			$sql = "select * from tvafa_realisasi where  number='$textidafa'";
		}
		$tbafa = myobj_table_to_object($app["link"],$sql);
		
		$nloop=0;
		forEach($tbafa as $k1=>$n1)
		{
			$tbafa[$nloop]->title = remove_special_char($n1->title) ;
			$nloop ++;
		}
		
		
		print  myobj_table_to_xml($tbafa) ;
		break ;
		
		case "detafa":
		$sql = "select id,afa_id,ifnull(price - terpakai,0) as price,price as budget,qty,description,terpakai as nclaim,id+afa_id as nptr from vafa_details where afa_id='$idafa'";
		$tbdafa = myobj_table_to_object($app["link"],$sql);
		
		$nloop = 0;
		forEach($tbdafa as $i=>$y)
		{
			$tbdafa[$nloop]->description = remove_special_char($y->description) ;
			$nloop ++;
		}
		print  myobj_table_to_xml($tbdafa) ; 
		break ;
		
		
		case "getafaapply":
		$sql = "select id,afa_id,afa_row_id,price,actual,tgltrx,idtrx,afa_id+afa_row_id as nptr from afa_drealisasi where afa_id='$idafa'";
		$tbapplydafa = myobj_table_to_object($app["link"],$sql);
		print myobj_table_to_xml($tbapplydafa);
		break;
		
		
		case "apllyafa":
		$head= $_POST["hxml"];
		$details = $_POST["dxml"];
		$hdata = xml_to_array($head);
		$ddata = xml_to_array($details);
		
		$sqlh = command_sql($app["link"],"afa_realisasi","ADD",$hdata["otbhafa"],"");
		if ( $app["link"]->query($sqlh) )
		{
			$rsp = "1#Succes#";
			$sqldet = "";
			$oDetails = $ddata["ctbdetafa"];
			forEach($oDetails as $key => $ptr)
			{
				$sqldet .= command_sql($app["link"],"afa_drealisasi","ADD",$ptr,"").";";
			}
			$app["link"]->multi_query($sqldet);
			
		
		}else
		{
			$rsp = "0#Error#".$app["link"]->error."#".$sqlh."#";
		}
		print $rsp; 
		break;
		
		case "testxml": 
		$details = $_POST["dxml"];
		 
		$array = xml_to_array($details); 
		$dx = $array["otbdetafa"];
		$sqldet = command_sql($app["link"],"afa_drealisasi","ADD",$dx[0] ,"").";";
		
		print_r ($sqldet);
		
		break ;
		
		default:
		
		echo "Request id: ".$q;
	}
	
	
	 
	
	
	
?>